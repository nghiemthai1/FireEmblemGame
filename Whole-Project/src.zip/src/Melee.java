public abstract class Melee extends Character{

 public Melee(int hp, int attackRange, int moveRange, int damage, int row, int col, String player, Field field, String fileName) {
  super(hp, attackRange, moveRange, damage, row, col, player, field,fileName);
  // TODO Auto-generated constructor stub
 }
 
}