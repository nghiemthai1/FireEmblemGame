import javax.swing.JOptionPane;

public abstract class Character {
	int hp;
	int attackRange;
	int moveRange;
	int damage;
	int maxHP;

	String fileName;

	boolean isAlive;
	private boolean readyToAttack;
	private boolean readyToMove;
	String player;
	Field field;
	Location previousLocation;
	Location currentLocation;

	public Character(int hp, int attackRange, int moveRange, int damage, int row, int col, String player, Field field,
			String fileName) {
		super();
		this.field = field;
		this.hp = hp;
		this.maxHP = hp;
		this.attackRange = attackRange;
		this.moveRange = moveRange;
		this.damage = damage;
		this.currentLocation = new Location(row, col);
		this.player = player;
		this.isAlive = true;
		this.readyToAttack = true;
		this.readyToMove = true;
		this.fileName = fileName;
	}

	// Getters and Setters

	public String getFileName() {
		return fileName;
	}

	protected boolean getReadyToAttack() {
		return readyToAttack;
	}

	protected void setReadyToAttack(boolean readyToAttack) {
		this.readyToAttack = readyToAttack;
	}

	protected boolean getReadyToMove() {
		return readyToMove;
	}

	protected void setReadyToMove(boolean readyToMove) {
		this.readyToMove = readyToMove;
	}

	protected String getPlayer() {
		return player;
	}

	protected void setPlayer(String player) {
		this.player = player;
	}

	public int getHP() {
		return hp;
	}

	public void setHP(int hp) {
		this.hp = hp;
	}

	public int getAttackRange() {
		return attackRange;
	}

	public void setAttackRange(int attackRange) {
		this.attackRange = attackRange;
	}

	public int getMoveRange() {
		return moveRange;
	}

	public void setMoveRange(int moveRange) {
		this.moveRange = moveRange;
	}

	public int getDamage() {
		return damage;
	}

	public void setDamage(int damage) {
		this.damage = damage;
	}

	public boolean isAlive() {
		return isAlive;
	}

	public void setAlive(boolean isAlive) {
		this.isAlive = isAlive;
	}

	public Field getField() {
		return field;
	}

	public void setField(Field field) {
		this.field = field;
	}

	public Location getPreviousLocation() {
		return previousLocation;
	}

	public void setPreviousLocation(Location previousLocation) {
		this.previousLocation = previousLocation;
	}

	public Location getCurrentLocation() {
		return currentLocation;
	}

	public void setCurrentLocation(Location currentLocation) {
		this.currentLocation = currentLocation;
	}

	// Methods

	public void attack (Character character){
		   character.takeDamage(this.damage);
		   if(character.getHP() == 0) {
		    character.setAlive(false);
		    JOptionPane.showMessageDialog(null, character.getClass() + " died.");  
		   }
		   else{
			   JOptionPane.showMessageDialog(null, this.getClass() + "attacked " + character.getClass() + "." + character
					     + " has " + character.getHP() + " HP left.");
		   }
		  }

	public void takeDamage(int damage) {
		setHP(hp - damage);
	}

	/*
	 * public void move (Location moveLocation){ Location = this.getLocation();
	 * 
	 * }
	 */

	public void setLocation(Location location) {
		previousLocation = currentLocation;
		System.out.println(location.getRow());
		if (currentLocation != null) {
			field.clear(currentLocation);
		}
		currentLocation = location;
		field.place(this, location);

	}

	public void moveBack() {
		setLocation(previousLocation);
	}

	public abstract int getCost();

	public abstract String toString();


	public int getHealAmount() {
		return 0;
	}

	public int getMaxHP() {
		return maxHP;
	}

	public void setMaxHP(int maxHP) {
		this.maxHP = maxHP;
	}

	public String getStats(){
		  String stats = this + "\n HP: " + getMaxHP() + "\n DAMAGE:" + getDamage() + "\n MOVEMENT RANGE: " + getMoveRange()
		  + "\n ATTACK RANGE: " + getAttackRange();
		  return stats;
		 }
}