import java.util.Random;

import javax.swing.JOptionPane;

public class Assassin extends Melee implements Critable,Avoidable{
 static final int maxHP = 200;
 static final int maxAttackRange = 1;
 static final int maxMovement = 5;
 static final int maxDamage = 250;
 static final int criChance = 50;
 int cost = 4;
 static final int criDMG = 2;
 static final int avoidability = 20;
  
  public Assassin(int row, int col,String player, Field field, String fileName) {
   super(maxHP, maxAttackRange, maxMovement, maxDamage,row, col, player, field, fileName);
   // TODO Auto-generated constructor stub
  }
  
  public void attack(Character character){
   int criRate = Critable.getBaseCrit() + criChance;
   int rand = new Random().nextInt(100);
   if((criRate >= rand)){
    character.takeDamage(criDMG*this.damage);
    if(character.getHP() == 0) {
      character.setAlive(false);
      JOptionPane.showMessageDialog(null, character.getClass() + " died to a critical hit.");
    }
    else{
     JOptionPane.showMessageDialog(null, this.getClass() + " attacked " + character.getClass() + ". It was a "
      + "critial hit!");
    }
   }
   else{
    super.attack(character);
   }
  }
  
  public void takeDamage(int damage){
   int avoidChance = Avoidable.baseAvoidability + avoidability;
   int rand = new Random().nextInt(100);
   if((avoidChance <= rand)){
    JOptionPane.showMessageDialog(null, this.getClass() + "avoided the attack.");
   }
   else{
    super.takeDamage(damage);
   }
  }
  
  

 @Override
 public String toString() {
  // TODO Auto-generated method stub
  return "Assassin";
 }
 
 public int getCost(){
  return cost;
 }
 
}