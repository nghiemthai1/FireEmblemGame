import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;

import javax.imageio.ImageIO;
import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

public class StartMenuGUI extends JFrame{
 
 private JFrame startFrame = new JFrame("Fire Emblem");
 
 private JPanel titlePanel = new JPanel();
 private JPanel buttonPanel = new JPanel();
 private String fileName;
 private String url;
 private UserCredentials userCredentials;
 private StartMenuGUI gui = this;
 

 JButton startButton;
 JButton tutorialButton;
 JButton creditsButton;
 JButton exitButton;

 public StartMenuGUI(String fileName, UserCredentials userCredentials) throws IOException{
  this.fileName = fileName;
  this.userCredentials = userCredentials;
  setUP();
  addComponents();
  placeGif(fileName);
  addListeners();
  startFrame.setVisible(true);
 }
 
 public void setUP(){
  startFrame.setSize(950, 400);
  this.setMaximumSize(new Dimension(20, 40));
  startFrame.setLayout(new BorderLayout());
  buttonPanel.setLayout(new GridLayout(5,1));
  startFrame.setName("Fire Emblem");
  
  setDefaultCloseOperation(EXIT_ON_CLOSE);

 }
 
 public void addComponents(){
  
  String platMember;
  if(userCredentials.isPlatinumMembership()){
   platMember = "True";
  }
  else{
   platMember = "False";
  }
  buttonPanel.add(new JLabel("User: " + userCredentials.getUser().toUpperCase() + 
    "\n Platinum Member: " + platMember)); 
  startButton = new JButton("Start Game");
  tutorialButton = new JButton("Tutorial");
  creditsButton = new JButton("Credits");
  exitButton = new JButton("Exit");
  startButton.setPreferredSize(new Dimension(100,100));
  tutorialButton.setPreferredSize(new Dimension(100,100));
  creditsButton.setPreferredSize(new Dimension(100,100));
  exitButton.setPreferredSize(new Dimension(100,100));
  
   
  
  
  buttonPanel.add(startButton);
  buttonPanel.add(tutorialButton);
  buttonPanel.add(creditsButton);
  buttonPanel.add(exitButton);
  
  startFrame.add(buttonPanel, BorderLayout.WEST);
  
 }
 
 public class exitListener implements ActionListener{
  public void actionPerformed(ActionEvent e){
   
    System.exit(0);
   
  }
 }
 
 public class tutorialListener implements ActionListener{
  public void actionPerformed(ActionEvent e){
   System.out.println("The rules of the game are: ");
  }
 }
 
 public class startListener implements ActionListener{
  public void actionPerformed(ActionEvent e){
	setVisible(false);
   new GameClient(gui);
  }
 }
 
 public class creditListener implements ActionListener{
  public void actionPerformed(ActionEvent e){
   System.out.println("Austin, Matt, Adam Chang, and Alexrdit worked on this game");
  }
 }
 
 public void addListeners(){
  exitButton.addActionListener(new exitListener());
  tutorialButton.addActionListener(new tutorialListener());
  creditsButton.addActionListener(new creditListener());
  startButton.addActionListener(new startListener());
 }
 
 public void placeImage(String fileName) {
    BufferedImage image;
    try {
     image = ImageIO.read(new File(fileName));
     ImageIcon imageIcon = new ImageIcon(image);
     JLabel titlePic = new JLabel(imageIcon);
     titlePic.setBorder(BorderFactory.createLineBorder(Color.BLACK));
     startFrame.add(titlePic,BorderLayout.CENTER);
    } catch (IOException e) {
     e.printStackTrace();
    }
 } 
 
 public void placeGif(String fileName)throws MalformedURLException{
  ImageIcon imageIcon;
  try{
   
   URL gifURL = new File(fileName).toURI().toURL();
   Icon icon = new ImageIcon(gifURL);
   JLabel titleGif = new JLabel(icon);
   titleGif.setBorder(BorderFactory.createLineBorder(Color.BLACK));
   
   JFrame gifFrame = new JFrame();
    startFrame.add(titleGif,BorderLayout.CENTER);
  }
  catch(Exception e){
   e.printStackTrace();
  }
 }
 
 public UserCredentials getUserCredentials() {
  return userCredentials;
 }

}