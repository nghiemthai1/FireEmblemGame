import java.util.Random;

import javax.swing.JOptionPane;

public class Archer extends Range implements Critable{

 static final int maxHP = 200;
 static final int maxAttackRange = 3;
 static final int maxMovement = 5;
 static final int maxDamage = 100;
 static final int criChance = 10;
 int cost = 2;
 static final int criDMG = 3;
 
 public Archer(int row, int col,String player, Field field, String fileName) {
  super(maxHP, maxAttackRange, maxMovement, maxDamage,row, col, player, field, fileName);
  // TODO Auto-generated constructor stub
 }

 public void attack(Character character){
	  int criRate = Critable.getBaseCrit() + criChance;
	  int rand = new Random().nextInt(100);
	  if((criRate >= rand)){
	   character.takeDamage(criDMG*this.damage);
	   if(character.getHP() == 0) {
	     character.setAlive(false);
	     JOptionPane.showMessageDialog(null, character.getClass() + " died to a critical hit.");
	   }
	   else{
	    JOptionPane.showMessageDialog(null, this.getClass() + " attacked " + character.getClass() + ". It was a "
	     + "critial hit! " + character + " has " + character.getHP() + 
	     " HP Left.");
	   }
	  }
	  else{
	   super.attack(character);
	  }
	 }
 
 public int getCost(){
	 return cost;
 }
 
 public String toString(){
	 return "Archer";
 }
 public String getStats(){
	  String stat = super.getStats();
	  stat = stat + "\n CRITICAL CHANCE: " + criChance + "\n CRITICAL DMG MULTIPLIER: " + criDMG + "\n COST: " + cost;
	  return stat;
	 }
}