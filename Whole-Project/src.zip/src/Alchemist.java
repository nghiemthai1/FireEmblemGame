import javax.swing.JOptionPane;

public class Alchemist extends Melee{
 static final int maxHP = 100;
  static final int maxAttackRange = 1;
  static final int maxMovement = 4;
  static final int maxDamage = 400;
  int cost = 1;
  
 public Alchemist(int row, int col, String player, Field field, String fileName) {
  super(maxHP, maxAttackRange, maxMovement, maxDamage, row, col, player, field, fileName);
  // TODO Auto-generated constructor stub
 }
 
 public void attack(){
  
 }
 
 public void attack (Character character){
    character.takeDamage(this.damage);
    if(character.getHP() == 0) {
     character.setAlive(false);
     JOptionPane.showMessageDialog(null, character.getClass() + " died."); 
     goInt();
    }
    else{
     JOptionPane.showMessageDialog(null, this.getClass() + " attacked " + character.getClass() + ".");
     
    }
   }
  
  public void takeDamage (int damage){
   setHP(hp - damage);
  }
  
 public void goInt(){
  this.setAlive(false);
 }
 

 @Override
 public String toString() {
  return "Alchemist";
 }
 
 public int getCost(){
	 return cost;
 }
 
}