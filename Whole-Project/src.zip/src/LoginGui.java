import java.awt.Color;
import java.awt.Component;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowEvent;
import java.io.File;
import java.io.IOException;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class LoginGui extends JFrame implements ActionListener {

 /**
  * 
  */
 private static final long serialVersionUID = 1L;

 private JFrame totalGUI = new JFrame("Login or Registration");

 private JPanel textPanel, panelForTextFields, completionPanel;
 private JLabel titleLabel, usernameLabel, passwordLabel, userLabel, passLabel;
 private JTextField usernameField, loginField;
 private JButton loginButton, registerButton;
 private UserCredentials u;

 public LoginGui() {
  this.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
  createGui();
  totalGUI.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
  totalGUI.setSize(260, 240);
  totalGUI.setVisible(true);
  JOptionPane.showMessageDialog(null, "Currently game is in beta testing. Platinum membership is given to all players for this period!");
 }

 private void createGui() {
  // Creates a bottom JPanel to place everything on.
  totalGUI.setLayout(null);

  titleLabel = new JLabel("Login Screen");
  titleLabel.setLocation(0, 0);
  titleLabel.setSize(290, 30);
  titleLabel.setHorizontalAlignment(0);
  totalGUI.add(titleLabel);

  // Creation of a Panel to contain the JLabels
  textPanel = new JPanel();
  textPanel.setLayout(null);
  textPanel.setLocation(10, 35);
  textPanel.setSize(70, 80);
  totalGUI.add(textPanel);

  // Username Label
  usernameLabel = new JLabel("Username");
  usernameLabel.setLocation(0, 0);
  usernameLabel.setSize(70, 40);
  usernameLabel.setHorizontalAlignment(4);
  textPanel.add(usernameLabel);

  // Login Label
  passwordLabel = new JLabel("Password");
  passwordLabel.setLocation(0, 40);
  passwordLabel.setSize(70, 40);
  passwordLabel.setHorizontalAlignment(4);
  textPanel.add(passwordLabel);

  // TextFields Panel Container
  panelForTextFields = new JPanel();
  panelForTextFields.setLayout(null);
  panelForTextFields.setLocation(110, 40);
  panelForTextFields.setSize(100, 70);
  totalGUI.add(panelForTextFields);

  // Username Textfield
  usernameField = new JTextField(8);
  usernameField.setLocation(0, 0);
  usernameField.setSize(100, 30);
  panelForTextFields.add(usernameField);

  // Login Textfield
  loginField = new JTextField(8);
  loginField.setLocation(0, 40);
  loginField.setSize(100, 30);
  panelForTextFields.add(loginField);

  // Creation of a Panel to contain the completion JLabels
  completionPanel = new JPanel();
  completionPanel.setLayout(null);
  completionPanel.setLocation(240, 35);
  completionPanel.setSize(70, 80);
  totalGUI.add(completionPanel);

  // Username Label
  userLabel = new JLabel();
  userLabel.setForeground(Color.red);
  userLabel.setLocation(0, 0);
  userLabel.setSize(100, 40);
  completionPanel.add(userLabel);

  // Login Label
  passLabel = new JLabel();
  passLabel.setForeground(Color.red);
  passLabel.setLocation(0, 40);
  passLabel.setSize(70, 40);
  completionPanel.add(passLabel);

  // Button for Logging in
  loginButton = new JButton("Login");
  loginButton.setLocation(130, 120);
  loginButton.setSize(80, 30);
  loginButton.addActionListener(this);
  totalGUI.add(loginButton);

  registerButton = new JButton("Register");
  registerButton.setLocation(25, 120);
  registerButton.setSize(90, 30);
  registerButton.addActionListener(this);
  totalGUI.add(registerButton);

 }

 public void actionPerformed(ActionEvent arg0) {

  Component frame = new JOptionPane();
  if (arg0.getSource() == loginButton) {
   if ((usernameField.getText() != null) && isValid(usernameField.getText())) {
    userLabel.setForeground(Color.green);
    userLabel.setText("yes");
    u = UserCredentials.deSerialize(usernameField.getText());
    System.out.println(loginField.getText());
    if (loginField.getText().equals(u.getPassword())) {
     try {
    	 setVisible(false);
    	 this.dispatchEvent(new WindowEvent(this, WindowEvent.WINDOW_CLOSING));
    	 this.dispose();
      StartMenuGUI startMenu = new StartMenuGUI("RadDawn.gif", u);
     } catch (IOException e) {
      // TODO Auto-generated catch block
      e.printStackTrace();
     }
    }
    else{
     
    }
   } else {
    JOptionPane.showMessageDialog(frame, "Invalid!");
   }

  }
  else if (arg0.getSource() == registerButton) {
   if (isValid(usernameField.getText())) {
    JOptionPane.showMessageDialog(frame, new DuplicateUsernameException().errormsg);
   } else {
    userLabel.setForeground(Color.green);
    userLabel.setText("you are good to go");
    UserCredentials u = new UserCredentials(usernameField.getText(), loginField.getText());
    this.u = u;
    u.serialize();
   }
  }

 }

 public static boolean isValid(String username) {
  boolean valid = false;
  File f = new File("C:\\Users\\matthew\\workspace\\users");
  String[] userNameList = f.list();
  username += ".txt";
  if(userNameList == null){
   return true;
  }
  for (String fileName : userNameList) {
   if (fileName.equals(username)) {
    valid = true;
   }
  }
  return valid;
 }

}