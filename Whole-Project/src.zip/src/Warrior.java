import java.util.Random;

import javax.swing.JOptionPane;

public class Warrior extends Melee implements Critable{
 
 static final int maxHP = 300;
 static final int maxAttackRange = 1;
 static final int maxMovement = 4;
 static final int maxDamage = 150;
 static final int criChance = 20;
 static final int criDMG = 2;
 int cost = 2;
 
 public Warrior(int row, int col, String player, Field field, String fileName) {
  super(maxHP, maxAttackRange, maxMovement, maxDamage, row, col, player, field, fileName);
  // TODO Auto-generated constructor stub
 }
 
 public void attack(Character character){
	  int criRate = Critable.getBaseCrit() + criChance;
	  int rand = new Random().nextInt(100);
	  if((criRate >= rand)){
	   character.takeDamage(criDMG*this.damage);
	   if(character.getHP() == 0) {
	     character.setAlive(false);
	     JOptionPane.showMessageDialog(null, character.getClass() + " died to a critical hit.");
	   }
	   else{
	    JOptionPane.showMessageDialog(null, this.getClass() + " attacked " + character.getClass() + ". It was a "
	     + "critial hit! " + character + " has " + character.getHP() + 
	     " HP Left.");
	   }
	  }
	  else{
	   super.attack(character);
	  }
	 }
 
 public int getCost(){
	 return cost;
 }
 
 public String toString(){
	 return "Warrior";
 }
 
 public String getStats(){
	  String stat = super.getStats();
	  stat = stat + "\n CRITICAL CHANCE: " + criChance + "\n CRITICAL DMG MULTIPLIER: " + criDMG + "\n COST: " + cost;
	  return stat;
	 }
 
}