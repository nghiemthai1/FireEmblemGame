public class Knight extends Melee{
 
 static final int maxHP = 600;
 static final int maxAttackRange = 1;
 static final int maxMovement = 3;
 static final int maxDamage = 100;
 int cost = 2;
 static final double bonusArmor = 0;
 
 public Knight(int row, int col, String player, Field field,String fileName) {
  super(maxHP, maxAttackRange, maxMovement, maxDamage, row, col, player,  field, fileName);
  // TODO Auto-generated constructor stub
 }
 
  public void takeDamage (int damage){
	  setHP((int)(hp - damage*(Armorable.getdmgTaken()-0)));
	 }
 
  public int getCost(){
		 return cost;
	 }
  
 public String toString(){
	 return "Knight";
 }
 
}