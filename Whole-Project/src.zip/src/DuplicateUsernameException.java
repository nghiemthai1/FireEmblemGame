public class DuplicateUsernameException extends Exception{

 public final String errormsg = "There is a user with that username, please pick a different username.";
}