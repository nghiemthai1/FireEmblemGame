public interface Armorable {
	
	static final double dmgTaken = 0.9;
	
	public static double getdmgTaken(){
		return dmgTaken;
	}
}