
public class Driver {

	public static void main(String[] args) {
		LoginGui lg = new LoginGui();
		  
		  Music music = new Music("TheDevoted.wav", "StalkingMenace.wav", "RadiantDawnOpening.wav",
		    "TheHydraeansWrath.wav", "FFXBattleTheme.wav");
		  
		  music.run();

	}

}
