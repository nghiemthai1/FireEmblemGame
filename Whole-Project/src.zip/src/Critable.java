public interface Critable {
	public static final int baseCrit = 15;
	
	public static int getBaseCrit(){
		return baseCrit;
	}
	
}
