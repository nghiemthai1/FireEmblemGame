public class Mage extends Range implements Healable{
 
 static final int maxHP = 150;
 static final int maxAttackRange = 2;
 static final int maxMovement = 3;
 static final int maxDamage = 300;
 int cost = 2;
 static final int healAmount= Healable.getBaseHeal();;

 public Mage(int row, int col, String player,  Field field, String fileName) {
  super(maxHP, maxAttackRange, maxMovement, maxDamage, row, col, player, field, fileName);
 }

 public void heal(Character character){
	    character.takeDamage(Healable.getBaseHeal());
	    if(character.getHP() > character.getMaxHP()){
	     character.setHP(character.maxHP);
	    }
	  }
 
 public int getCost(){
	 return cost;
 }
 
 public String toString(){
	 return "Mage";
 }
 
 public int getHealAmount(){
	 return healAmount;
 }
}